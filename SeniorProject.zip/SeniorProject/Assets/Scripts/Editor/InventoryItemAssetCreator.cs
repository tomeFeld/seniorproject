﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class InventoryItemAssetCreator : MonoBehaviour 
{
	[MenuItem("Assets/Create/Inventory/Item")]
	public static void CreateAsset()
	{
		CustomAssetUtility.CreateAsset<InventoryItem> ();
	}
}
