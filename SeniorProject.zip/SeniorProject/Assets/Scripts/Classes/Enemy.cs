﻿using UnityEngine;
using System.Collections;

public class Enemy : Entity
{
	public EnemyClass Class;
}
