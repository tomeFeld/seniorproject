﻿public enum EnemyClass
{
	Goblin,
	Ork,
	NastyPieceOfWork
}
