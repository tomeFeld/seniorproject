﻿using UnityEngine;
using System.Collections;

public class ConversationComponent : MonoBehaviour
{
	public Conversation[] Conversations;
}
