﻿using UnityEngine;
using System.Collections;

public class InventoryItem : ScriptableObject
{
	public Sprite sprite;
	public Vector3 Scale;
	public string ItemName;
	public int Cost;
	public int strength;
	public int Defense;
}

