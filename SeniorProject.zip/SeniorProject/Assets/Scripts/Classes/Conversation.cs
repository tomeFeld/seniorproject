﻿using UnityEngine;
using System.Collections;

public class Conversation : ScriptableObject
{
	public ConversationEntry[] ConversationLines;
}
