﻿using UnityEngine;
using System.Collections;

public class Npc : MonoBehaviour 
{
	public string Name;
	public int Age;
	public string Faction;
	public string Occupation;
	public int level;
}
