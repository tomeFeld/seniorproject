﻿using UnityEngine;
using System.Collections;

public class PlayerInventoryDisplay : MonoBehaviour 
{
	bool displayInventory = false;
	Rect inventoryWindowRect;
	private Vector2 inventoryWindowSize = new Vector2 (150, 150);
	Vector2 inventoryItemIconSize = new Vector2(130,32);

	float offSetX = 6;
	float offSetY = 6;

	void Awake()
	{
		inventoryWindowRect = new Rect (Screen.width - inventoryWindowSize.x, Screen.height - inventoryWindowSize.y, inventoryWindowSize.x, inventoryWindowSize.y);
	}

	void OnGUI()
	{
		if (Input.GetKeyDown (KeyCode.I))
			displayInventory = !displayInventory;
		if (displayInventory) 
		{
			inventoryWindowRect = GUI.Window (0, inventoryWindowRect, DisplayInventoryWindow, "Inventory");
			inventoryWindowSize = new Vector2 (inventoryWindowRect.width, inventoryWindowRect.height);
		}
	}

	void DisplayInventoryWindow(int windowID)
	{
		var currentX = 0 + offSetX;
		var currentY = 18 + offSetY;
		foreach (var item in GameState.CurrentPlayer.Inventory) 
		{
			Rect texcoords = item.sprite.textureRect;
			texcoords.x /= item.sprite.texture.width;
			texcoords.y /= item.sprite.texture.height;
			texcoords.width /= item.sprite.texture.width;
			texcoords.height /= item.sprite.texture.height;

			GUI.DrawTextureWithTexCoords(new Rect(currentX, currentY, item.sprite.textureRect.width, item.sprite.textureRect.height), item.sprite.texture, texcoords);

			currentX += inventoryItemIconSize.x;
			if (currentX + inventoryItemIconSize.x + offSetX > inventoryWindowSize.x) 
			{
				currentX = offSetX;
				currentY += inventoryItemIconSize.y;
				if (currentY + inventoryItemIconSize.y + offSetY > inventoryWindowSize.y) 
				{
					return;
				}
			}
		}
	}
}
