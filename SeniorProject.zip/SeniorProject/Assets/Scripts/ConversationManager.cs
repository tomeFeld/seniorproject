﻿using UnityEngine;
using System.Collections;

public class ConversationManager : Singleton<ConversationManager>
{
	//Guarantee this will always be a singleton only - can't use the constructor
	protected ConversationManager(){}

	public void StartConversation(Conversation conversation)
	{
		//Start displaying the supplied conversation
		if (!talking) 
		{
			StartCoroutine (DisplayConversation (conversation));
		}
	}

	//Is there a conversation going on
	bool talking = false;

	//The current line of text being displayed
	ConversationEntry currentConversationLine;

	//Estimated width of characters in the font
	int fontSpacing = 7;

	//How wide does the dialog window need to be
	int conversationTextWidth;

	//How high does the dialog window need to be
	int dialogHeight = 70;

	//Offset space needed for character image
	public int displayTextureOffset = 70;

	//Scaled image rectangle for displaying character image
	Rect scaledTextureRect;

	IEnumerator DisplayConversation(Conversation conversation)
	{
		talking = true;
		foreach (var conversationLine in conversation.ConversationLines) 
		{
			currentConversationLine = conversationLine;
			conversationTextWidth = currentConversationLine.ConversationText.Length * fontSpacing;

			scaledTextureRect = new Rect (currentConversationLine.DisplayPic.textureRect.x / currentConversationLine.DisplayPic.texture.width,
				currentConversationLine.DisplayPic.textureRect.y / currentConversationLine.DisplayPic.texture.height,
				currentConversationLine.DisplayPic.textureRect.width / currentConversationLine.DisplayPic.texture.width,
				currentConversationLine.DisplayPic.textureRect.height / currentConversationLine.DisplayPic.texture.height);

			yield return new WaitForSeconds (3);
		}
		talking = false;
		yield return null;
	}

	void OnGUI()
	{
		if (talking) 
		{
			//Layout start
			GUI.BeginGroup(new Rect(Screen.width/2 - conversationTextWidth/2, 50, conversationTextWidth+displayTextureOffset+10, dialogHeight));

			//The background box
			GUI.Box(new Rect(0,0, conversationTextWidth+displayTextureOffset+10, dialogHeight),"");

			//The character name
			GUI.Label(new Rect(displayTextureOffset,10,conversationTextWidth+30,20),currentConversationLine.SpeakingCharacterName);

			//The conversation text
			GUI.Label(new Rect(displayTextureOffset,30,conversationTextWidth+30,20),currentConversationLine.ConversationText);

			//The character image
			GUI.DrawTextureWithTexCoords(new Rect(10,10,50,50),currentConversationLine.DisplayPic.texture,scaledTextureRect);

			//Layout end
			GUI.EndGroup();
		}
	}
}
