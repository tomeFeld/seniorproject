﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public static class NavigationManager
{
	private static string PreviousLocation;

	public struct Route
	{
		public string RouteDescription;
		public bool CanTravel;
	}

	public static Dictionary<string, Route> RouteInformation = new Dictionary<string, Route> () 
	{
		{ "World", new Route{RouteDescription = "the overworld", CanTravel = true}},
		{ "Cave", new Route{RouteDescription =  "the ancient cave", CanTravel = false}},
		{ "Home", new Route{RouteDescription = "your hometown", CanTravel = true}},
		{"Castle", new Route{RouteDescription = "the castle of poison tears", CanTravel = true}},
		{"Elves", new Route{RouteDescription = "the elven forest", CanTravel = true}},
		{"Mutant", new Route{RouteDescription = "the destroyed city", CanTravel = true}},
		{"Undead", new Route{RouteDescription = "the lair of the undead", CanTravel = true}},
		{"Underwater", new Route{RouteDescription = "to the ocean floor", CanTravel = true}},
		{"Shop", new Route {CanTravel = true}},
	};
		
	public static string GetRouteInfo(string destination)
	{
		return RouteInformation.ContainsKey (destination) ? RouteInformation [destination].RouteDescription : null;
	}

	public static bool CanNavigate(string destination)
	{
		return RouteInformation.ContainsKey (destination) ? RouteInformation [destination].CanTravel : false;
	}

	public static void NavigateTo(string destination)
	{
		PreviousLocation = SceneManager.GetActiveScene ().name;
		if (destination == "Home")
			GameState.PlayerReturningHome = false;
		FadeinOutManager.FadeToLevel (destination, 2f, 2f, Color.black);
	}

	public static void GoBack()
	{
		var backlocation = PreviousLocation;
		PreviousLocation = SceneManager.GetActiveScene ().name;
		SceneManager.LoadScene (backlocation);
		//FadeinOutManager.FadeToLevel (backlocation);
	}
}
