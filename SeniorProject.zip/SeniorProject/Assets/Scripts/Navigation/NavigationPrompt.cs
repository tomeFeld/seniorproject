﻿using UnityEngine;
using System.Collections;

public class NavigationPrompt : MonoBehaviour 
{
	bool showDialog;

	//Show travel GUI on collision enter
	void OnCollisionEnter2D(Collision2D col)
	{
		//Only allow the player to travel if allowed
		if (NavigationManager.CanNavigate(this.tag))
		{
			DialogVisible(true);
		}
	}

	//Hide travel GUI on collision exit
	void OnCollisionExit2D(Collision2D col)
	{
		DialogVisible(false);
	}

	//Show travel GUI on trigger enter
	void OnTriggerEnter2D(Collider2D col)
	{
		//Only allow the player to travel if allowed
		if (NavigationManager.CanNavigate (this.tag)) 
		{
			DialogVisible(true);
		}
	}

	//Send message on whether GUI should be visible or invisible
	void DialogVisible(bool visibility)
	{
		showDialog = visibility;
		MessagingManager.Instance.BroadcastUIEvent(visibility);
	}

	void OnGUI()
	{
		if (showDialog) 
		{
			//layout start
			GUI.BeginGroup(new Rect(Screen.width/2-150, 50, 300, 250));

			//the menu background box
			GUI.Box(new Rect(0, 0 ,300, 250), "");

			//Information text
			GUI.Label(new Rect(15, 10, 300, 68), "Do you want to travel to " + NavigationManager.GetRouteInfo(this.tag) + "?");

			//Player wants to leave this location
			if (GUI.Button (new Rect (55, 100, 180, 40), "Travel")) 
			{
				showDialog = false;
				NavigationManager.NavigateTo (this.tag);
			}

			//Player wants to stay at this location
			if (GUI.Button (new Rect (55, 150, 180, 40), "Stay")) 
			{
				DialogVisible(false);
			}

			//layout end
			GUI.EndGroup();
		}
	}
}
